package com.ibm.magentopages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ForgetPwdPage {
	WebDriverWait wait;
	WebDriver driver;
	
	By errorMsg= By.className("validation-advice");
	By validEmailAddr=By.className("validation-advice");

	public ForgetPwdPage(WebDriver driver, WebDriverWait wait)
	{
		PageFactory.initElements(driver, this);
		this.driver=driver;
		this.wait=wait;
	}
	//Intializing webelement using page factory
	@FindBy(how=How.XPATH,using="//span[text()='Submit']")WebElement submit;
	@FindBy(how=How.NAME,using="email")WebElement email;
	
	//Creating method for each action
	public ForgetPwdPage clickSubmitButton()
	{
		submit.click();
		return this;
	}
	public String getPageSourceVerifyErrorMessage()
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(errorMsg));
		
		return driver.getPageSource();
	}
	public void enterEmail(String uname)
	{
		email.sendKeys(uname);
	}
	public String getPageSourceValidEmailAddr()
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(validEmailAddr));
		
		return driver.getPageSource();
}
}
